from django.contrib import admin
from django.utils.safestring import mark_safe 
from .models import Doctor, Patient, Appointment ,Speciality ,Profession

@admin.register(Doctor)
class DoctorAdmin(admin.ModelAdmin):
    list_display = ('id', 'name', 'mobile', 'profession', 'image_tag')  
    search_fields = ('name', 'profession')
    list_filter = ('profession',)
    readonly_fields = ('image_tag',) 
    
    def image_tag(self, obj):
        if obj.image:
            return mark_safe('<img src="{}" style="height: 50px; width:50px;" />'.format(obj.image.url))
        else:
            return None

    image_tag.short_description = 'Image Preview' 


@admin.register(Patient)
class PatientAdmin(admin.ModelAdmin):
    list_display = ('id', 'name', 'age', 'gender', 'mobile', 'address')
    search_fields = ('name', 'mobile')
    list_filter = ('gender',)

@admin.register(Appointment)
class AppointmentAdmin(admin.ModelAdmin):
    list_display = ('id', 'doctor', 'patient','specialty','appointment_date', 'appointment_time')
    search_fields = ('doctor__name', 'patient__name')
    list_filter = ('doctor', 'appointment_date')

@admin.register(Speciality)
class SpecialityAdmin(admin.ModelAdmin):
    list_display = ('name', 'description', 'original_price', 'discounted_price', 'discount','image')

@admin.register(Profession)
class ProfessionAdmin(admin.ModelAdmin):
    list_display = ('name', 'speciality')
    search_fields = ('name',)
    list_filter = ('speciality',)

# Alternatively, you can use admin.site.register if you don't want to use the decorator style

# admin.site.register(Doctor, DoctorAdmin)
# admin.site.register(Patient, PatientAdmin)
# admin.site.register(Appointment, AppointmentAdmin)
