from django.db import models,connection


class Speciality(models.Model):
    name = models.CharField(max_length=100)
    description = models.TextField()
    original_price = models.DecimalField(max_digits=10, decimal_places=2)
    discounted_price = models.DecimalField(max_digits=10, decimal_places=2)
    discount = models.PositiveIntegerField()
    image = models.ImageField(upload_to='specialty_images/', null=True, blank=True)

    def __str__(self):
        return self.name

class Profession(models.Model):
    name = models.CharField(max_length=100)  
    speciality = models.ForeignKey(Speciality, on_delete=models.CASCADE)

    def __str__(self):
        return self.name

class Doctor(models.Model):
    name = models.CharField(max_length=50)
    mobile = models.CharField(max_length=15)
    profession = models.ForeignKey(Profession, on_delete=models.CASCADE,null=True)
    image = models.ImageField(upload_to='doctor_images/', null=True, blank=True)

    def __str__(self):
        return self.name

    def save(self, *args, **kwargs):
        if not self.pk:
            latest_doctor = Doctor.objects.order_by('-id').first()
            if latest_doctor:
                self.id = latest_doctor.id + 1
            else:
                self.id = 1
        return super().save(*args, **kwargs)


class Patient(models.Model):
    GENDER_CHOICES = [
        ('male', 'Male'),
        ('female', 'Female'),
        ('other', 'Other'),
    ]
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=50)
    age = models.IntegerField(null=True)
    gender = models.CharField(max_length=10, choices=GENDER_CHOICES)
    mobile = models.CharField(max_length=15)
    address = models.CharField(max_length=100)

    def __str__(self):
        return self.name
    
    def save(self, *args, **kwargs):
        if not self.id:
            # Calculate the next ID
            last_patient = Patient.objects.order_by('-id').first()
            if last_patient:
                self.id = last_patient.id + 1
            else:
                self.id = 1
        super().save(*args, **kwargs)

class Appointment(models.Model):
    id = models.AutoField(primary_key=True)
    doctor = models.ForeignKey('Doctor', on_delete=models.CASCADE)
    patient = models.ForeignKey('Patient', on_delete=models.CASCADE, null=True)
    specialty = models.ForeignKey(Speciality, on_delete=models.CASCADE, null=True)
    symptom_description = models.TextField(default='', blank=True)
    appointment_date = models.DateField(null=True)
    appointment_time = models.TimeField(null=True)

    def __str__(self):
        return f'Appointment with Dr. {self.doctor.name} for {self.patient.name} on {self.appointment_date} at {self.appointment_time}'
    
    def save(self, *args, **kwargs):
        if not self.id:
            # Calculate the next ID
            last_appointment = Appointment.objects.order_by('-id').first()
            if last_appointment:
                self.id = last_appointment.id + 1
            else:
                self.id = 1
        super().save(*args, **kwargs)