from django.shortcuts import render, redirect ,get_object_or_404
from django.views.generic import TemplateView
from django.contrib.auth import authenticate, login as auth_login ,logout
from django.contrib import messages
from .forms import LoginForm ,RegistrationForm,DoctorForm , PatientForm ,SpecialityForm ,AppointmentForm
from django.contrib.auth.models import User
import time
from django.contrib.auth.decorators import login_required
from .models import Doctor,Patient ,Speciality ,Appointment
from django.db.models import Count
import random
from urllib.parse import urlparse, parse_qs, unquote

class HomeView(TemplateView):
    template_name = 'home.html'

    def dispatch(self, request, *args, **kwargs):
        if not request.user.is_authenticated or not request.user.is_staff:
            return redirect('login')
        return super().dispatch(request, *args, **kwargs)
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        
        # Aggregate counts
        doctor_count = Doctor.objects.aggregate(d=Count('id'))
        patient_count = Patient.objects.aggregate(p=Count('id'))
        speciality_count = Speciality.objects.aggregate(s=Count('id'))
        appointment_count = Appointment.objects.aggregate(a=Count('id'))

        # Update context with aggregated counts
        context.update({
            'doctor_count': doctor_count['d'],
            'patient_count': patient_count['p'],
            'speciality_count': speciality_count['s'],
            'appointment_count': appointment_count['a'],
        })

        return context

def index(request):
    specialities = Speciality.objects.all()
    return render(request, 'index.html', {'specialities': specialities})

def contact_us(request):
    return render(request, 'contact_us.html')

def about_us(request):
    return render(request, 'about_us.html')

def login(request):
    next_url = request.GET.get('next', '')  # Get the next parameter from the URL
    next_url = unquote(next_url)  # Decode the next parameter if it's encoded

    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            user = authenticate(request, username=username, password=password)
            if user is not None:
                auth_login(request, user)
                messages.success(request, 'Login successful!')
                if next_url:
                    return redirect(next_url)  # Redirect to the next URL if it exists
                elif user.is_staff:
                    return redirect('home')  # Redirect to home page for staff users
                else:
                    return redirect('index')  # Redirect to a different page for non-staff users
            else:
                return render(request, 'login.html', {'form': form, 'error': 'Invalid username or password'})
    else:
        form = LoginForm()
    return render(request, 'login.html', {'form': form, 'next': next_url})

def register(request):
    if request.method == 'POST':
        form = RegistrationForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            email = form.cleaned_data['email']
            password = form.cleaned_data['password']
            confirm_password = form.cleaned_data['confirm_password']
            if password == confirm_password:
                if User.objects.filter(username=username).exists():
                    messages.error(request, 'Username already exists')
                elif User.objects.filter(email=email).exists():
                    messages.error(request, 'Email already exists')
                else:
                    user = User.objects.create_user(username=username, email=email, password=password)
                    user.save()
                    messages.success(request, 'Registration successful! Please log in.')
                    return redirect('login')
            else:
                messages.error(request, 'Passwords do not match')
    else:
        form = RegistrationForm()
    return render(request, 'register.html', {'form': form})

def logout_admin(request):
    if request.user.is_authenticated and request.user.is_staff:
        logout(request)
        messages.success(request, 'Admin has successfully logged out.')
    return redirect('login')

def logout_user(request):
    if request.user.is_authenticated and not request.user.is_staff:
        logout(request)
        messages.success(request, 'You have successfully logged out.')
    return redirect('login')


def find_doctors(request, speciality_id=None):
    if speciality_id:
        speciality = get_object_or_404(Speciality, id=speciality_id)
        doctors = Doctor.objects.filter(profession__speciality=speciality)
    else:
        doctors = Doctor.objects.all()
    
    is_authenticated = request.user.is_authenticated
    is_staff = request.user.is_staff
    
    return render(request, 'find_doctors.html', {
        'doctors': doctors, 
        'selected_speciality_id': speciality_id,
        'is_authenticated': is_authenticated,
        'is_staff': is_staff,})


def book_appointment(request):
    if not request.user.is_authenticated and request.user.is_staff:
        return redirect('login')
    # Initialize or increment the session counter
    if 'appointment_call_count' not in request.session:
        request.session['appointment_call_count'] = 0
        request.session['seed_index'] = 0

    request.session['appointment_call_count'] += 1

    # Define the seeds to use
    seeds = [1234, 5678, 91011, 121314, 151617]

    # Change the seed every 5 calls
    if request.session['appointment_call_count'] > 5:
        request.session['appointment_call_count'] = 1
        request.session['seed_index'] = (request.session['seed_index'] + 1) % len(seeds)

    current_seed = seeds[request.session['seed_index']]
    random.seed(current_seed)

    all_times = ['09:00', '09:30', '10:00', '10:30', '11:00', '11:30', 
                 '12:00', '12:30', '13:00', '13:30', '14:00', '14:30', 
                 '15:00', '15:30', '16:00', '16:30', '17:00', '17:30']

    # Sample the times and sort them
    sampled_times = random.sample(all_times, min(5, len(all_times)))
    available_times = sorted(sampled_times)
    
    if request.method == 'POST':
        patient_form = PatientForm(request.POST)
        appointment_form = AppointmentForm(request.POST, available_times=available_times)
        
        if patient_form.is_valid() and appointment_form.is_valid():
            patient = patient_form.save()
            
            doctor = appointment_form.cleaned_data['doctor']
            specialty = appointment_form.cleaned_data['specialty']
            appointment_date = appointment_form.cleaned_data['appointment_date']
            appointment_time = appointment_form.cleaned_data['appointment_time']
            symptom_description = appointment_form.cleaned_data['symptom_description']
            
            appointment = Appointment(
                patient=patient,
                doctor=doctor,
                specialty=specialty,
                appointment_date=appointment_date,
                appointment_time=appointment_time,
                symptom_description=symptom_description
            )
            appointment.save()
        
            messages.success(request, 'You will soon receive a contact from the hospital.')
            return redirect('success_view')
    
    else:
        doctor_id = request.GET.get('doctor_id')
        speciality_id = request.GET.get('speciality_id')
        initial_data = {}
        if doctor_id:
            initial_data['doctor'] = Doctor.objects.get(pk=doctor_id)
        if speciality_id:
            initial_data['specialty'] = Speciality.objects.get(pk=speciality_id)

        patient_form = PatientForm()
        appointment_form = AppointmentForm(initial=initial_data, available_times=available_times)
    
    context = {
        'patient_form': patient_form,
        'appointment_form': appointment_form,
        'doctors': Doctor.objects.all(),
        'specialities': Speciality.objects.all(),
        'available_times': available_times,
    }
    return render(request, 'book_appointment.html', context)


def home (request):
    if not request.user.is_staff:
        return redirect(login)
    return render (request,'home.html')

# Doctor views
def doctor_list(request):
    if not request.user.is_staff:
        return redirect('login')
    docs = Doctor.objects.all().order_by('id')
    context = {'docs': docs}
    return render(request, 'doctor_list.html', context)

def delete_doctor(request, doctor_id):
    if not request.user.is_staff:
        return redirect('login')
    doctor = get_object_or_404(Doctor, pk=doctor_id)
    if request.method == 'POST':
        doctor.delete()
        remaining_doctors = Doctor.objects.all()
        for index, doctor in enumerate(remaining_doctors, start=1):
            doctor.id = index
            doctor.save()
        messages.success(request, 'Doctor deleted successfully.')
        return redirect('doctor_list')
    return redirect('doctor_list')


def add_doctor(request):
    if not request.user.is_staff:
        return redirect('login')

    if request.method == 'POST':
        form = DoctorForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Doctor added successfully.')
            # time.sleep(2)
            return redirect('doctor_list')
    else:
        form = DoctorForm()
    return render(request, 'add_doctor.html', {'form': form})

def update_doctor(request, doctor_id):
    doctor = get_object_or_404(Doctor, id=doctor_id)
    if request.method == 'POST':
        form = DoctorForm(request.POST, request.FILES, instance=doctor)
        if form.is_valid():
            form.save()
            messages.success(request, 'Doctor details updated successfully.')
            return redirect('doctor_list')
    else:
        form = DoctorForm(instance=doctor)
    return render(request, 'update_doctor.html', {'form': form, 'doctor': doctor})

# Patient views
def patient_list(request):
    if not request.user.is_staff:
        return redirect('login')
    patients = Patient.objects.all().order_by('id')
    context = {'patients': patients}
    return render(request, 'patient_list.html', context)

def delete_patient(request, patient_id):
    if not request.user.is_staff:
        return redirect('login')
    
    patient = get_object_or_404(Patient, pk=patient_id)
    
    if request.method == 'POST':
        patient.delete()
        messages.success(request, 'Patient deleted successfully.')
    return redirect('patient_list')

def add_patient(request):
    if not request.user.is_staff:
        return redirect('login')

    if request.method == 'POST':
        form = PatientForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Patient added successfully.')
            return redirect('patient_list')
    else:
        form = PatientForm()
    return render(request, 'add_patient.html', {'form': form})

def update_patient(request, patient_id):
    patient = get_object_or_404(Patient, id=patient_id)
    if request.method == 'POST':
        form = PatientForm(request.POST, instance=patient)
        if form.is_valid():
            form.save()
            messages.success(request, 'Patient details updated successfully.')
            return redirect('patient_list')
    else:
        form = PatientForm(instance=patient)
    return render(request, 'update_patient.html', {'form': form, 'patient': patient})


def specialty_list(request):
    specialties = Speciality.objects.all()
    return render(request, 'speciality_list.html', {'specialties': specialties})

def add_specialty(request):
    if request.method == 'POST':
        form = SpecialityForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('specialty_list')
    else:
        form = SpecialityForm()
    return render(request, 'add_speciality.html', {'form': form})


def delete_specialty(request, specialty_id):
    if not request.user.is_staff:
        return redirect('login')
    
    specialty = get_object_or_404(Speciality, pk=specialty_id)
    
    if request.method == 'POST':
        specialty.delete()
        messages.success(request, 'Specialty deleted successfully.')
    return redirect('specialty_list')

def update_specialty(request, specialty_id):
    specialty = get_object_or_404(Speciality, id=specialty_id)
    if request.method == 'POST':
        form = SpecialityForm(request.POST, request.FILES, instance=specialty)
        if form.is_valid():
            form.save()
            messages.success(request, 'Specialty updated successfully.')
            return redirect('specialty_list')
    else:
        form = SpecialityForm(instance=specialty)
    return render(request, 'update_specialty.html', {'form': form, 'specialty': specialty})

# List appointments
def appointment_list(request):
    if not request.user.is_staff:
        return redirect('login')
    appointments = Appointment.objects.all().order_by('id')
    context = {'appointments': appointments}
    return render(request, 'appointment_list.html', context)


DEFAULT_PATIENT_ID = 1
# Add appointment
def add_appointment(request):
    if not request.user.is_staff:
        return redirect('login')

    default_patient = Patient.objects.get(pk=DEFAULT_PATIENT_ID)

    # Initialize or increment the session counter
    if 'appointment_call_count' not in request.session:
        request.session['appointment_call_count'] = 0
        request.session['seed_index'] = 0

    request.session['appointment_call_count'] += 1
    
    # Define the seeds to use
    seeds = [1234, 5678, 91011, 121314, 151617]

    # Change the seed every 4 calls
    if request.session['appointment_call_count'] > 4:
        request.session['appointment_call_count'] = 1
        request.session['seed_index'] = (request.session['seed_index'] + 1) % len(seeds)
    
    current_seed = seeds[request.session['seed_index']]
    random.seed(current_seed)

    all_times = ['09:00', '09:30', '10:00', '10:30', '11:00', '11:30', 
                 '12:00', '12:30', '13:00', '13:30', '14:00', '14:30', 
                 '15:00', '15:30', '16:00', '16:30', '17:00', '17:30']
    available_times = sorted(random.sample(all_times, min(5, len(all_times))))

    if request.method == 'POST':
        form = AppointmentForm(request.POST, available_times=available_times)
        if form.is_valid():
            doctor = form.cleaned_data['doctor']
            specialty = form.cleaned_data['specialty']
            appointment_date = form.cleaned_data['appointment_date']
            appointment_time = form.cleaned_data['appointment_time']
            symptom_description = form.cleaned_data['symptom_description']
            
            appointment = Appointment(
                patient=default_patient,  # Set the default patient here for now
                doctor=doctor,
                speciality=specialty,
                appointment_date=appointment_date,
                appointment_time=appointment_time,
                symptom_description=symptom_description
            )
            appointment.save()
            messages.success(request, 'Appointment added successfully.')
            return redirect('appointment_list')
    else:
        form = AppointmentForm(available_times=available_times)
    
    return render(request, 'add_appointment.html', {'form': form})

# Delete appointment
def delete_appointment(request, appointment_id):
    if not request.user.is_staff:
        return redirect('login')
    
    appointment = get_object_or_404(Appointment, pk=appointment_id)
    
    if request.method == 'POST':
        appointment.delete()
        messages.success(request, 'Appointment deleted successfully.')
        return redirect('appointment_list')

    return render(request, 'confirm_delete.html', {'appointment': appointment})

def update_appointment(request, appointment_id):
    if not request.user.is_staff:
        return redirect('login')
    default_patient = Patient.objects.get(pk=DEFAULT_PATIENT_ID)

    # Initialize or increment the session counter
    if 'appointment_call_count' not in request.session:
        request.session['appointment_call_count'] = 0
        request.session['seed_index'] = 0

    request.session['appointment_call_count'] += 1
    
    # Define the seeds to use
    seeds = [1234, 5678, 91011, 121314, 151617]

    # Change the seed every 5 calls
    if request.session['appointment_call_count'] > 5:
        request.session['appointment_call_count'] = 1
        request.session['seed_index'] = (request.session['seed_index'] + 1) % len(seeds)
    
    current_seed = seeds[request.session['seed_index']]
    random.seed(current_seed)

    all_times = ['09:00', '09:30', '10:00', '10:30', '11:00', '11:30', 
                 '12:00', '12:30', '13:00', '13:30', '14:00', '14:30', 
                 '15:00', '15:30', '16:00', '16:30', '17:00', '17:30']
    available_times = sorted(random.sample(all_times, min(5, len(all_times))))

    appointment = get_object_or_404(Appointment, id=appointment_id)
    if request.method == 'POST':
        form = AppointmentForm(request.POST, instance=appointment, available_times=available_times)
        if form.is_valid():
            form.save()
            messages.success(request, 'Appointment updated successfully.')
            return redirect('appointment_list')
    else:
        form = AppointmentForm(instance=appointment, available_times=available_times)
    return render(request, 'update_appointment.html', {'form': form, 'appointment': appointment})

def success_view(request):
    if not request.user.is_authenticated and request.user.is_staff:
        return redirect('login')
    appointment = Appointment.objects.all().order_by('-id').first()
    context = { 'appointment': appointment}  
    return render(request, 'success.html', context)