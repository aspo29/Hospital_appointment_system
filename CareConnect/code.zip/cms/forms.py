from django import forms
from .models import Doctor ,Patient ,Speciality ,Appointment
from datetime import date
class LoginForm(forms.Form):
     username = forms.CharField(max_length=150, label='Username', widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter username'}))
     password = forms.CharField(widget=forms.PasswordInput(attrs={'class': 'form-control', 'placeholder': 'Enter password'}), label='Password')

class RegistrationForm(forms.Form):
    username = forms.CharField( max_length=150, widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter username'}),label='Username')
    email = forms.EmailField(widget=forms.EmailInput(attrs={'class': 'form-control', 'placeholder': 'Enter email'}),label='Email')
    password = forms.CharField(widget=forms.PasswordInput(attrs={'class': 'form-control', 'placeholder': 'Enter password'}),label='Password')
    confirm_password = forms.CharField(widget=forms.PasswordInput(attrs={'class': 'form-control', 'placeholder': 'Confirm password'}),label='Confirm Password')

    def clean(self):
        cleaned_data = super().clean()
        password = cleaned_data.get('password')
        confirm_password = cleaned_data.get('confirm_password')

        if password != confirm_password:
            raise forms.ValidationError('Passwords do not match')

class DoctorForm(forms.ModelForm):
    class Meta:
        model = Doctor
        fields = ['id', 'name', 'mobile', 'profession', 'image'] 
        widgets = {
            'id': forms.HiddenInput(attrs={'class': 'form-control'}),
            'name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter name'}),
            'mobile': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter mobile'}),
            'profession': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter profession'}),
            'image': forms.ClearableFileInput(attrs={'class': 'form-control-file'}) 
        }


class PatientForm(forms.ModelForm):
    class Meta:
        model = Patient
        fields = ['name', 'age', 'gender', 'mobile', 'address']
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter name'}),
            'age': forms.NumberInput(attrs={'class': 'form-control', 'placeholder': 'Enter age'}),
            'gender': forms.Select(attrs={'class': 'form-control'}, choices=[('male', 'Male'), ('female', 'Female'), ('other', 'Other')]),
            'mobile': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter mobile number'}),
            'address': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter address'}),
        }

class SpecialityForm(forms.ModelForm):
    class Meta:
        model = Speciality
        fields = ['name', 'description', 'original_price', 'discounted_price', 'discount', 'image']
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter name'}),
            'description': forms.Textarea(attrs={'class': 'form-control', 'placeholder': 'Enter description'}),
            'original_price': forms.NumberInput(attrs={'class': 'form-control', 'placeholder': 'Enter original price'}),
            'discounted_price': forms.NumberInput(attrs={'class': 'form-control', 'placeholder': 'Enter discounted price'}),
            'discount': forms.NumberInput(attrs={'class': 'form-control', 'placeholder': 'Enter discount'}),
            'image': forms.ClearableFileInput(attrs={'class': 'form-control-file'}),
        }

PAYMENT_CHOICES = [
    ('fonepay', 'FonePay'),
    ('khalti', 'Khalti'),
    ('hbl', 'HBL'),
    ('esewa', 'eSewa'),
]

class AppointmentForm(forms.ModelForm):
    doctor = forms.ModelChoiceField(queryset=Doctor.objects.all(), required=True, label='Doctor', widget=forms.Select(attrs={'class': 'form-select'}))
    # patient = forms.ModelChoiceField(queryset=Patient.objects.all(), required=True, label='Patient', widget=forms.Select(attrs={'class': 'form-select'}))
    specialty = forms.ModelChoiceField(queryset=Speciality.objects.all(), required=True, label='Specialty', widget=forms.Select(attrs={'class': 'form-select'}))
    appointment_date = forms.DateField(initial=date.today, widget=forms.SelectDateWidget(years=range(date.today().year, date.today().year + 5), attrs={'class': 'form-select', 'style': 'width: 32.2%; display: inline-block;'}), required=True, label='Date')
    appointment_time = forms.ChoiceField(choices=[], required=True, label='Time', widget=forms.Select(attrs={'class': 'form-select'}))
    symptom_description = forms.CharField(widget=forms.Textarea(attrs={'class': 'form-control', 'rows': 4}), required=False, label='Symptoms (if any)')
    payment_method = forms.ChoiceField(choices=PAYMENT_CHOICES, widget=forms.RadioSelect(), label='Select Payment Method')
    
    class Meta:
        model = Appointment
        fields = ['doctor', 'specialty', 'appointment_date', 'appointment_time', 'symptom_description', 'payment_method']

    def __init__(self, *args, **kwargs):
        available_times = kwargs.pop('available_times', []) 
        super().__init__(*args, **kwargs)
        self.fields['appointment_time'].choices = [(time, time) for time in available_times]

